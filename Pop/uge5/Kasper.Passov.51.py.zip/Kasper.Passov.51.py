# -*- coding: cp1252 -*-

from kursusuge5modul import *

# global variables 
HEIGHT = 32
WIDTH = 32
LEVER = []
# jeg har valgt at skrive globale variabler i store bogstaver for
# nemmere at kunne adskilde dem fra lokale variabler og funktioner

########################
##        API         ##
########################

def start():
    """testfunktion til at starte model med mindre indtastning"""
    visLife(foerste, naeste, levende, klik)

def foerste():
    """Starter modelen"""
    return (0,HEIGHT-1,0,WIDTH-1)

def naeste():
    """itterere modelen en tidsenhed"""
    global LEVER 

    lever_n = []
    for i in range(0,HEIGHT): 
        for j in range(0, WIDTH):
            if __check_om_skal_leve(i,j): 
                lever_n.append((i,j))

    LEVER = lever_n
    return (0,HEIGHT-1,0,WIDTH-1)

def levende(i,j):
    """returnere true hvis (i,j) er et levende element"""
    return (i,j) in LEVER

def klik(i,j):
    """hvis (i,j) er levende bliver den dræbt, hvis den er død bliver den
       opliver"""
    if levende(i,j):
        LEVER.remove((i,j))
    else:
        LEVER.append((i,j))

############################
##    Hjælpefunktioner    ##
############################

def __levende_omkring(levende_naboer,(i,j)):
    """returnere levende_naboer + 1 hvis (i,j) er et levende element"""
    if levende(i,j): 
        levende_naboer += 1
    return levende_naboer


def __alle_naboer(i,j):
    """returnere en liste med elementets 8 naboer"""
    return [(i-1,j+1), (i  ,j+1), (i+1,j+1), 
            (i-1,j  ),            (i+1,j  ),
            (i-1,j-1), (i  ,j-1), (i+1,j-1)]

def __check_om_skal_leve(i,j):
    """checker om det pågældene element burde leve, og gemmer elementet i
       listen lever_n hvis dette er tilfældet"""
    antal_levende = reduce(__levende_omkring, __alle_naboer(i,j), 0)
    if not levende(i,j):
        if antal_levende == 3: # hvis den er død og 3 levende omkring
           return True 
    else:
        if antal_levende in [2,3]: # hvis den lever og 2-3 levende omkring
           return True
    return False # hvis den skal være død

