-module(at_misc).
-export([id/1]).


id(X) -> X.
