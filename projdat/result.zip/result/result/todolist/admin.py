from models import TodoItem
from django.contrib import admin

admin.site.register(TodoItem)
