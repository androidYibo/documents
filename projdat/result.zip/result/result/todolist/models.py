from django.db import models
from datetime import datetime

class TodoItem(models.Model):
	created_date = models.DateTimeField(default=datetime.now())
	task = models.CharField(max_length=50)
	done = models.BooleanField(default=False)

	def __unicode__(self):
		done_string = ""
		if self.done:
			done_string = "(done)"

		return " ".join([self.task, done_string])
